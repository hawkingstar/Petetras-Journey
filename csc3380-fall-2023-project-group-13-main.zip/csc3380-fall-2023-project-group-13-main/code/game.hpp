#pragma once
#include<iostream>
//#include<stdlib.h>

#include"character.hpp"
#include"dungeon.hpp"
void gameover();
int main();