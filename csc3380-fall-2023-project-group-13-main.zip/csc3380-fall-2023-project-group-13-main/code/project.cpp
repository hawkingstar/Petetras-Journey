
/*#include <iostream>

int main()
{
    std::cout << "Hello from the project starter code!\n";
    return 0;
}
*/